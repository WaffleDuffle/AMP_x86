Instalati emulatorul, preferabil in calea "C:\emu8086".
Copiati fisierul "reg.ini" in directorul unde a fost instalat emulatorul (aceeasi cu cea de mai sus).